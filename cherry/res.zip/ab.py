print "chuiouy"
















